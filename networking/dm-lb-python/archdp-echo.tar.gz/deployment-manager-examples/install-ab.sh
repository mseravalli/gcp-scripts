#!/bin/bash -e
apt-get update
apt-get -y install apache2-utils

